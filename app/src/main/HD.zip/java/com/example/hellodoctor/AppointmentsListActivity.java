package com.example.hellodoctor;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AppointmentsListActivity extends AppCompatActivity {

    private ListView appointmentsListView;
    private List<PatientAppointment> appointmentList; // Updated to PatientAppointment
    private BookingAppointmentListAdapter appointmentAdapter; // Updated to BookingAppointmentListAdapter

    private DatabaseReference patientAppointmentsRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointments_list);

        appointmentsListView = findViewById(R.id.appointmentsListView);
        appointmentList = new ArrayList<>();
        appointmentAdapter = new BookingAppointmentListAdapter(this, appointmentList); // Updated to BookingAppointmentListAdapter
        appointmentsListView.setAdapter(appointmentAdapter);

        patientAppointmentsRef = FirebaseDatabase.getInstance().getReference("patient_appointments");

        fetchAppointments();
    }

    private void fetchAppointments() {
        patientAppointmentsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                appointmentList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    PatientAppointment appointment = snapshot.getValue(PatientAppointment.class); // Updated to PatientAppointment
                    if (appointment != null) {
                        appointmentList.add(appointment);
                    }
                }
                appointmentAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(AppointmentsListActivity.this, "Failed to load appointments: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
