package com.example.hellodoctor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class BookingAppointmentListAdapter extends ArrayAdapter<PatientAppointment> {

    private Context context;
    private List<PatientAppointment> appointments;

    public BookingAppointmentListAdapter(Context context, List<PatientAppointment> appointments) {
        super(context, 0, appointments);
        this.context = context;
        this.appointments = appointments;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.booking_item_appointment, parent, false);
        }

        PatientAppointment appointment = getItem(position);

        TextView doctorNameTextView = convertView.findViewById(R.id.doctorNameTextView);
        TextView dateTextView = convertView.findViewById(R.id.dateTextView);
        TextView timeSlotTextView = convertView.findViewById(R.id.timeSlotTextView);
        TextView slotNumberTextView = convertView.findViewById(R.id.slotNumberTextView);
        TextView usernameTextView = convertView.findViewById(R.id.usernameTextView); // Ensure this field is included

        if (appointment != null) {
            doctorNameTextView.setText(appointment.getDoctorName());
            dateTextView.setText(appointment.getDate());
            timeSlotTextView.setText(appointment.getTimeSlot());
            slotNumberTextView.setText(String.valueOf(appointment.getSlotNumber()));
            usernameTextView.setText(appointment.getUsername()); // Display the username
        }

        return convertView;
    }
}
