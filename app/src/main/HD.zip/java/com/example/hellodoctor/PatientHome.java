package com.example.hellodoctor;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class PatientHome extends AppCompatActivity {

    private RecyclerView recyclerViewDoctors;
    private pDoctorAdapter doctorAdapter;
    private List<pDoctor> doctorList;
    private DatabaseReference databaseReference;
    private ProgressBar progressBar;
    private TextView textViewNoDoctors;
    private LinearLayout logoutLayout;
    private LinearLayout appointmentsLayout;  // Add this line

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_home);

        // Initialize Firebase Database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("doctors");

        // Initialize UI elements
        recyclerViewDoctors = findViewById(R.id.recyclerViewDoctors);
        progressBar = findViewById(R.id.progressBar);
        textViewNoDoctors = findViewById(R.id.textViewNoDoctors);
        logoutLayout = findViewById(R.id.logoutLayout);
        appointmentsLayout = findViewById(R.id.appointmentsLayout);  // Initialize LinearLayout for appointments

        recyclerViewDoctors.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the list and adapter
        doctorList = new ArrayList<>();
        doctorAdapter = new pDoctorAdapter(this, doctorList);
        recyclerViewDoctors.setAdapter(doctorAdapter);

        // Get user data from the intent
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String email = intent.getStringExtra("email");
        String username = intent.getStringExtra("username");
        String password = intent.getStringExtra("password");

        // Set up the user profile picture click listener
        ImageView userProfilePic = findViewById(R.id.userProfilePic);
        userProfilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pass user data to ProfileActivity
                Intent profileIntent = new Intent(PatientHome.this, ProfileActivity.class);
                profileIntent.putExtra("name", name);
                profileIntent.putExtra("email", email);
                profileIntent.putExtra("username", username);
                profileIntent.putExtra("password", password);
                startActivity(profileIntent);
            }
        });

        // Set up the log out button click listener
        logoutLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToLoginActivity();
            }
        });

        // Set up the appointments button click listener
        appointmentsLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent appointmentsIntent = new Intent(PatientHome.this, AppointmentsListActivity.class);
                startActivity(appointmentsIntent);
            }
        });

        // Fetch all doctors from Firebase
        fetchDoctors();
    }

    private void fetchDoctors() {
        // Show loading indicator
        progressBar.setVisibility(View.VISIBLE);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                doctorList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    pDoctor doctor = snapshot.getValue(pDoctor.class);
                    if (doctor != null) {
                        doctor.setId(snapshot.getKey());
                        doctorList.add(doctor);
                    }
                }

                // Check if the doctor list is empty
                if (doctorList.isEmpty()) {
                    textViewNoDoctors.setVisibility(View.VISIBLE);
                    recyclerViewDoctors.setVisibility(View.GONE);
                } else {
                    textViewNoDoctors.setVisibility(View.GONE);
                    recyclerViewDoctors.setVisibility(View.VISIBLE);
                }

                doctorAdapter.notifyDataSetChanged();

                // Hide loading indicator
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(PatientHome.this, "Failed to load data: " + databaseError.getMessage(), Toast.LENGTH_LONG).show();

                // Hide loading indicator
                progressBar.setVisibility(View.GONE);
            }
        });
    }

    private void navigateToLoginActivity() {
        Intent intent = new Intent(PatientHome.this, LoginActivity.class);
        startActivity(intent);
        finish(); // Optional: Finish this activity to prevent the user from navigating back to it
    }
}
